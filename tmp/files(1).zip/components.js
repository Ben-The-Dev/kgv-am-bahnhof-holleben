// Loads shared nav and footer, then marks the active nav link.
(async function () {
  const BASE = document.currentScript
    ? new URL(document.currentScript.src).origin
    : '';

  async function loadComponent(selector, url) {
    const el = document.querySelector(selector);
    if (!el) return;
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(res.status);
      el.outerHTML = await res.text();
    } catch (e) {
      console.warn('Component load failed:', url, e);
    }
  }

  // Resolve path relative to root so it works in /parzellen/ sub-pages too
  const root = BASE + '/components/';
  await Promise.all([
    loadComponent('#nav-placeholder',    root + 'nav.html'),
    loadComponent('#footer-placeholder', root + 'footer.html'),
  ]);

  // Mark active nav link
  const path = location.pathname.replace(/\/$/, '') || '/aktuelles.html';
  document.querySelectorAll('.nav-links a').forEach(a => {
    const href = new URL(a.href).pathname;
    if (href === path || (path.startsWith('/parzellen') && href.includes('/parzellen'))) {
      a.classList.add('active');
    }
  });
})();
